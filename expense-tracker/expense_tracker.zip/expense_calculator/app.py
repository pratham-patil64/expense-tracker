from flask import Flask, render_template, request, redirect, session, url_for, jsonify
from datetime import datetime, timedelta
from collections import defaultdict, OrderedDict
import psycopg2
import hashlib

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Change to a secure, random key in production

# PostgreSQL connection
conn = psycopg2.connect(
    dbname="expense_tracker",
    user="postgres",
    password="Pratham@0604",
    host="localhost",
    port="5432"
)
cur = conn.cursor()

# Create tables if not exists
cur.execute("""
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL
);
""")

cur.execute("""
CREATE TABLE IF NOT EXISTS expenses (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    description TEXT,
    amount NUMERIC,
    category TEXT,
    date DATE DEFAULT CURRENT_DATE
);
""")
conn.commit()

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/dashboard')
def dashboard():
    cur.execute("SELECT * FROM expenses")
    expenses = cur.fetchall()
    return render_template('index.html', expenses=expenses)

@app.route('/add', methods=['POST'])
def add():
    description = request.form['description']
    amount = request.form['amount']
    category = request.form['category']
    cur.execute("INSERT INTO expenses (description, amount, category) VALUES (%s, %s, %s)",
                (description, amount, category))
    conn.commit()
    return redirect(url_for('home', saved=1))

@app.route('/all-expenses')
def all_expenses():
    cur.execute("SELECT * FROM expenses")
    expenses = cur.fetchall()
    return render_template('all_expenses.html', expenses=expenses)

@app.route('/report')
def report():
    # Fetch all expenses with date
    cur.execute("SELECT category, amount, date FROM expenses ORDER BY date ASC")
    data = cur.fetchall()

    # Category totals
    category_totals = defaultdict(float)
    total = 0
    for cat, amt, _ in data:
        category_totals[cat] += float(amt)
        total += float(amt)
    categories = list(category_totals.keys())
    amounts = [category_totals[cat] for cat in categories]

    # Prepare weekly and monthly data
    weekly = defaultdict(float)
    monthly = defaultdict(float)
    yearly = defaultdict(float)

    for _, amt, date in data:
        if not isinstance(date, datetime):
            date = datetime.strptime(str(date), "%Y-%m-%d")
        week = date.strftime("%Y-W%U")
        month = date.strftime("%Y-%m")
        year = date.strftime("%Y")
        weekly[week] += float(amt)
        monthly[month] += float(amt)
        yearly[year] += float(amt)

    # Sort for chart display
    weekly = OrderedDict(sorted(weekly.items()))
    monthly = OrderedDict(sorted(monthly.items()))
    yearly = OrderedDict(sorted(yearly.items()))

    return render_template(
        'report.html',
        categories=categories,
        amounts=amounts,
        total=total,
        weekly_labels=list(weekly.keys()),
        weekly_amounts=list(weekly.values()),
        monthly_labels=list(monthly.keys()),
        monthly_amounts=list(monthly.values()),
        yearly_labels=list(yearly.keys()),
        yearly_amounts=list(yearly.values())
    )

@app.route('/delete-expense/<int:expense_id>', methods=['POST'])
def delete_expense(expense_id):
    cur.execute("DELETE FROM expenses WHERE id = %s", (expense_id,))
    conn.commit()
    return redirect(url_for('all_expenses'))

if __name__ == '__main__':
    app.run(debug=True)

